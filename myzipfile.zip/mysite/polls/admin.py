from django.contrib import admin
from .models import Users,Project, LstUsd
# Register your models here.

admin.site.register(Users)
admin.site.register(Project)
admin.site.register(LstUsd)